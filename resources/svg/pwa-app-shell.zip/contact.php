<?php
$pageTitle = "Kontakt";
include_once $_SERVER["DOCUMENT_ROOT"] . "/assets/incl/header.php";
?>

<?php
include_once $_SERVER["DOCUMENT_ROOT"] . "/assets/incl/footer.php";
?>